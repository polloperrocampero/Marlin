#ifndef _LEVELING_H_
#define _LEVELING_H_

void menuManualLeveling(void);
void menuAutoLeveling(void);

#endif
