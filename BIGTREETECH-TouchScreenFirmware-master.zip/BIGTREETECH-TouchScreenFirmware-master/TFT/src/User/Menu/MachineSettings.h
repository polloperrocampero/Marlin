#ifndef _MACHINE_SETTINGS_H_
#define _MACHINE_SETTINGS_H_

void menuRGBSettings(void);
void menuMachineSettings(void);
void menuCustom(void);

#endif
