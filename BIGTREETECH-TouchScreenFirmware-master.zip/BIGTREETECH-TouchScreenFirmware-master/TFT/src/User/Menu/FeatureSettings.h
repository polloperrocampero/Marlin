#ifndef _FEATURE_SETTINGS_H_
#define _FEATURE_SETTINGS_H_

void menuFeatureSettings(void);

#endif
