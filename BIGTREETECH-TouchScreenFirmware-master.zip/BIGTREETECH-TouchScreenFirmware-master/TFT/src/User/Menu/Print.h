#ifndef _PRINT_H_
#define _PRINT_H_
#include "includes.h"

void menuPrintFromSource(void);
void menuPrint(void);
bool get_Pre_Icon(void);

#endif
