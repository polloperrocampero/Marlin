#ifndef _MODE_H_
#define _MODE_H_


void infoMenuSelect(void);
void menuMode(void);

void Serial_ReSourceDeInit(void);
void Serial_ReSourceInit(void);
#endif
