#ifndef _UNIFIEDMOVE_H_
#define _UNIFIEDMOVE_H_

void menuUnifiedMove(void);

#endif
